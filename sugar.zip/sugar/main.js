/** SUGAR SYNTAX **/

//¿Qué es? La utilización de operadores avanzados con la idea de simplificar el código. 

//1) Plantillas Literales: las usamos a traves de las backsticks (alt+96)
//Me permite simplificar la concatenación de datos. 

let nombre = "Pepe Argento"; 
let trabajo = "Zapatería"; 

let mensaje = `${nombre} trabaja en una ${trabajo} `;

console.log(mensaje);

//2) Operador Ternario: Es una simplificación de la estructura if/else. 

//Sintaxis: condicion ? codigoSiEsVerdad : codigoSiEsFalso

let llueve = false;

console.log(llueve ? "tortas fritas y netflix" : "hacemos picnic");

let respuesta = llueve ? "cucharear" : "ir a trabajar";

console.log(respuesta);

//3) Operador spread: Operador de propagación. (...)
//Se utiliza con elementos iterables (arrays, objetos) enviando cada uno de sus elementos de forma individual como  parámetro a una función. 

const nombres = ["Juan", 10, "Maria", true]; 

console.log(nombres);

//Si utilizo el operador spread:

console.log(...nombres);

console.log(nombres[0], nombres[1], nombres[2], nombres[3]);

//Copiar información: 

const alumno = {
    nombre: "Coki",
    apellido: "Argento",
    edad: 45
};

const alumnoDos = alumno;
//Esto no lo hacemos!! Si hago esto, estoy copiando la referencia en memoria. 

alumnoDos.nombre = "Paola";

//console.log(alumnoDos);
//console.log(alumno);

//¿Cómo es la forma correcta de copiar objetos? 

const alumnoTres = {...alumno};

alumno.nombre = "Fatiga"; 

console.log(alumnoTres);
console.log(alumno);

//Copiamos arrays: 

const a = [1,2,3,4];
const b = [5,6,7,8]; 
const nuevoArray = [...a, ...b];
console.log(nuevoArray);

//4) Desestructuración de Objetos: 
//Nos permite desempaquetar valores de arrays u objetos en distintas variables. 

//Ejemplo: 

const bart = {
    nombre:"Bart",
    apellido: "Simpson",
    edad: 10,
    escuela: "Sprinfield Elementary School"
}

//Hago lo siguiente: 

let {nombre:nombrecito, apellido, edad, escuela} = bart;

console.log(nombre);
console.log(nombrecito);
console.log(apellido);

//5) Desestructuración de Arrays: 

let frutas = ["Manzana", "Pera", "Naranja", "Vino"];

let [,,fruta2, fruta3] = frutas;

console.log(fruta3);

//6) Acceso condicional a las propiedades de un objeto: 

const empleado = null;

console.log(empleado?.nombre);

//alert("ayudame loco!!");

//Lo utilizo para controlar errores y evitar que se rompa la aplicación. 









